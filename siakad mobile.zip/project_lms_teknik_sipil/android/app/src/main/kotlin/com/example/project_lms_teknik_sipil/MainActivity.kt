package com.example.project_lms_teknik_sipil

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
