import 'package:flutter/material.dart';

class logoDanNamaPolinema extends StatelessWidget {
  const logoDanNamaPolinema({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          "SISTEM AKADEMIK",
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
        ),
      ],
    );
  }
}
